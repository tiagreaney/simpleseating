if __name__ == "__main__":  # pragma: no cover
    from pip._vendor.rich.console import Console
    from pip._vendor.rich import inspect

    console = Console()
    inspect(console)
